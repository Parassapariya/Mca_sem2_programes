package com.example.androidprojects;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Lv_Array_Custom extends AppCompatActivity {

    private static class ListItem {
        final int icon;
        final String title;
        final String subtitle;

        ListItem(int icon, String title, String subtitle) {
            this.icon = icon;
            this.title = title;
            this.subtitle = subtitle;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lv_array_custom);

        // Sample data - replace with your actual data
        ArrayList<ListItem> items = new ArrayList<>();
        items.add(new ListItem(R.drawable.india, "Android", "Google's mobile OS"));
        items.add(new ListItem(R.drawable.india, "iOS", "Apple's mobile OS"));
        items.add(new ListItem(R.drawable.india, "Windows", "Microsoft's desktop OS"));
        items.add(new ListItem(R.drawable.india, "Linux", "Open-source OS"));

        // Get ListView reference
        ListView listView = findViewById(R.id.listView);

        // Set custom adapter
        listView.setAdapter(new CustomAdapter(this, items));
    }

    // Custom adapter implementation
    private static class CustomAdapter extends ArrayAdapter<ListItem> {
        CustomAdapter(Context context, ArrayList<ListItem> items) {
            super(context, 0, items);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;

            if (convertView == null) {
                // Create main container
                LinearLayout container = new LinearLayout(getContext());
                container.setOrientation(LinearLayout.HORIZONTAL);
                container.setPadding(16, 16, 16, 16);

                // Create ImageView
                ImageView icon = new ImageView(getContext());
                icon.setLayoutParams(new LinearLayout.LayoutParams(100, 100));

                // Create text container
                LinearLayout textContainer = new LinearLayout(getContext());
                textContainer.setOrientation(LinearLayout.VERTICAL);
                textContainer.setPadding(16, 0, 0, 0);

                // Create TextViews
                TextView title = new TextView(getContext());
                title.setTextSize(18);
                title.setTextColor(0xFF000000);

                TextView subtitle = new TextView(getContext());
                subtitle.setTextSize(14);
                subtitle.setTextColor(0xFF666666);

                // Add views to containers
                textContainer.addView(title);
                textContainer.addView(subtitle);
                container.addView(icon);
                container.addView(textContainer);

                // Set up ViewHolder
                holder = new ViewHolder();
                holder.icon = icon;
                holder.title = title;
                holder.subtitle = subtitle;
                container.setTag(holder);

                convertView = container;
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            // Get current item
            ListItem item = getItem(position);

            // Populate views
            if (item != null) {
                holder.icon.setImageResource(item.icon);
                holder.title.setText(item.title);
                holder.subtitle.setText(item.subtitle);
            }

            return convertView;
        }

        // ViewHolder pattern for better performance
        private static class ViewHolder {
            ImageView icon;
            TextView title;
            TextView subtitle;
        }
    }
}