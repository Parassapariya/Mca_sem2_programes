package com.example.androidprojects;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Tab2Fragment extends Fragment {

    public Tab2Fragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_tab1_fragment, container, false);

        ListView listView = rootView.findViewById(R.id.listView);
        List<HashMap<String, String>> dataList = new ArrayList<>();

        String[][] rows = {
                {"Resume", "Program 1"},
                {"Flag Display", "Program 2"},

        };

        for (String[] row : rows) {
            HashMap<String, String> rowMap = new HashMap<>();
            rowMap.put("title", row[0]);
            rowMap.put("value", row[1]);
            dataList.add(rowMap);
        }

        SimpleAdapter adapter = new SimpleAdapter(
                getContext(),
                dataList,
                android.R.layout.simple_list_item_2,
                new String[]{"title", "value"},
                new int[]{android.R.id.text1, android.R.id.text2}
        );

        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            HashMap<String, String> selectedItem = (HashMap<String, String>) parent.getItemAtPosition(position);
            String type = selectedItem.get("title");

            Toast.makeText(getContext(), type, Toast.LENGTH_SHORT).show();

            Class<?> targetActivity;
            if (position == 0) {
                targetActivity = ResumeT1.class;
            } else if (position == 1) {
                targetActivity = FlagDisplay_G_B.class;
            } else if (position == 2) {
                targetActivity = LifeCycleExample.class;
            } else {
                return;
            }

            Intent intent = new Intent(getContext(), targetActivity);
            startActivity(intent);
        });

        return rootView;
    }
}
