package com.example.androidprojects;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Radio_Imageview extends AppCompatActivity {

    private RadioGroup radioGroup;
    private ImageView imageViewFlag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_imageview);

        radioGroup = findViewById(R.id.radioGroup);
        imageViewFlag = findViewById(R.id.imageViewFlag);

        // Set listener for radio group changes
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                
                RadioButton selectedRadioButton = findViewById(checkedId);
                if (selectedRadioButton != null) {

                    switch (selectedRadioButton.getId()) {
                        case R.id.radioButtonFlag1:
                            imageViewFlag.setImageResource(R.drawable.india);
                            break;
                        case R.id.radioButtonFlag2:
                            imageViewFlag.setImageResource(R.drawable.australia);
                            break;
                    }
                }
            }
        });
    }
}