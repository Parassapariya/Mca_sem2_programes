# Univ-Transport-Management
University Transport Management System is a website developed to help students of university find details of the transport facilities who are in collaboration with 
university. 

The system consists of two modules:
Student module: Provides complete detailed information regarding transport facilities available from their cities to university,
                Students can book or delete the booking and also can submit a feedback for the same.
                
Trasnport Authority Module: This module is for the transport authority who will add the details regarding the transport services offered by them. 
                            They can add, update or delete their details as per the requirements.
                            Can display the booking details of stundents.
                            Can view feedbacks provided by students.
                            
The project is developed using HTML, CSS, Javascript and Firebase.

