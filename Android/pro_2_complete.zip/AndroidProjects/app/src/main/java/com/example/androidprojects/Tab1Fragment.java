package com.example.androidprojects;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Tab1Fragment extends Fragment {

    public Tab1Fragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_tab1_fragment, container, false);

        ListView listView = rootView.findViewById(R.id.listView);
        List<HashMap<String, String>> dataList = new ArrayList<>();

        String[][] rows = {
                {"HelloWorld", "Program 1"},
                {"Toast", "Program 2"},
                {"LifeCycle", "Program 3"}
        };

        for (String[] row : rows) {
            HashMap<String, String> rowMap = new HashMap<>();
            rowMap.put("title", row[0]);
            rowMap.put("value", row[1]);
            dataList.add(rowMap);
        }

        SimpleAdapter adapter = new SimpleAdapter(
                getContext(),
                dataList,
                android.R.layout.simple_list_item_2,
                new String[]{"title", "value"},
                new int[]{android.R.id.text1, android.R.id.text2}
        );

        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            HashMap<String, String> selectedItem = (HashMap<String, String>) parent.getItemAtPosition(position);
            String type = selectedItem.get("title");

            Toast.makeText(getContext(), type, Toast.LENGTH_SHORT).show();

            Class<?> targetActivity;
            if (position == 0) {
                targetActivity = HelloWorld.class;
            } else if (position == 1) {
                targetActivity = ToastExample.class;
            } else if (position == 2) {
                targetActivity = LifeCycleExample.class;
            } else {
                return;
            }

            Intent intent = new Intent(getContext(), targetActivity);
            startActivity(intent);
        });

        return rootView;
    }
}
