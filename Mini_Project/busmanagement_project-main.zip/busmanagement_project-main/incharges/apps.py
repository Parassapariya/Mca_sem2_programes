from django.apps import AppConfig


class InchargesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'incharges'
