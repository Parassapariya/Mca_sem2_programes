package com.example.androidprojects;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FlagDisplay_G_B extends AppCompatActivity {

    private final int[] flagResources = {
            R.drawable.australia,

    };

    // Country names
    private final String[] countryNames = {
            "USA"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flag_display_gb);

        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(new FlagAdapter(this));
    }

    private class FlagAdapter extends BaseAdapter {
        private final Context context;

        public FlagAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return flagResources.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;

            if (convertView == null) {
                // Create container programmatically
                LinearLayout container = new LinearLayout(context);
                container.setOrientation(LinearLayout.VERTICAL);
                container.setPadding(16, 16, 16, 16);

                // Create ImageView
                ImageView iv = new ImageView(context);
                iv.setLayoutParams(new ViewGroup.LayoutParams(200, 200));
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);

                // Create TextView
                TextView tv = new TextView(context);
                tv.setLayoutParams(new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                ));
                tv.setTextSize(14);
                tv.setPadding(0, 8, 0, 0);

                // Add views to container
                container.addView(iv);
                container.addView(tv);

                // Set up ViewHolder
                holder = new ViewHolder();
                holder.flagImage = iv;
                holder.countryText = tv;
                container.setTag(holder);

                convertView = container;
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            // Set data
            holder.flagImage.setImageResource(flagResources[position]);
            holder.countryText.setText(countryNames[position]);

            return convertView;
        }

        class ViewHolder {
            ImageView flagImage;
            TextView countryText;
        }
    }
}